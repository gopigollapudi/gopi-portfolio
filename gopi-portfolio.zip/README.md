
# Gopi Gollapudi — Cybersecurity Portfolio

This is a ready-to-deploy static portfolio website built for Gopi Gollapudi.
Included:
- index.html
- assets/gopi_pic.jpg

How to preview locally:
1. unzip gopi-portfolio.zip
2. open index.html in your browser (or use a local server like `python -m http.server`)

How to deploy:
- Upload to GitHub Pages or Netlify.
